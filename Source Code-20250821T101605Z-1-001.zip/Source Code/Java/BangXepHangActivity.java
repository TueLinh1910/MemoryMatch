package com.example.memorymatch;

import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.widget.Button;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

public class BangXepHangActivity extends AppCompatActivity {
    private RecyclerView recyclerView;
    private Button btnDe, btnThuong, btnKho, btnChoiGame, btnQuayLai;
    private DBHelper dbHelper;
    private String email = "";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_bang_xep_hang);

        recyclerView = findViewById(R.id.recyclerViewScores);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        btnDe = findViewById(R.id.btnDe);
        btnThuong = findViewById(R.id.btnThuong);
        btnKho = findViewById(R.id.btnKho);
        btnChoiGame = findViewById(R.id.btnChoiGame);
        btnQuayLai = findViewById(R.id.btnBack);
        dbHelper = new DBHelper(this);
        email = getIntent().getStringExtra("email");
        btnDe.setOnClickListener(v -> {
            doiMauNut(btnDe);
            hienThiBXH("de");
        });
        btnThuong.setOnClickListener(v -> {
            doiMauNut(btnThuong);
            hienThiBXH("thuong");
        });
        btnKho.setOnClickListener(v -> {
            doiMauNut(btnKho);
            hienThiBXH("kho");
        });
        btnChoiGame.setOnClickListener(v -> {
            Intent intent = new Intent(BangXepHangActivity.this, ChonManActivity.class);
            intent.putExtra("email", email);
            intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
            startActivity(intent);
            finish();
        });
        btnQuayLai.setOnClickListener(v -> finish());
        doiMauNut(btnDe);
        hienThiBXH("de");
    }

    private void hienThiBXH(String doKho) {
        List<DiemSoGame> danhSach = dbHelper.layBXH(doKho);
        recyclerView.setAdapter(new BXHAdapter(danhSach));
    }
    private void doiMauNut(Button nutDangChon) {
        // Reset 3 nút về màu xám
        btnDe.setBackgroundTintList(getColorStateList(R.color.grey_button));
        btnThuong.setBackgroundTintList(getColorStateList(R.color.grey_button));
        btnKho.setBackgroundTintList(getColorStateList(R.color.grey_button));
        btnDe.setTextColor(Color.BLACK);
        btnThuong.setTextColor(Color.BLACK);
        btnKho.setTextColor(Color.BLACK);

        // Nút đang chọn sẽ thành màu xanh
        nutDangChon.setBackgroundTintList(getColorStateList(R.color.green_button));
        nutDangChon.setTextColor(Color.WHITE);
    }
}


