package com.example.memorymatch;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    private LinearLayout layoutChuaDangNhap, layoutDaDangNhap;
    private Button btnDangNhap, btnDangKy, btnChoiGame, btnDangXuat, btnBangXepHang;
    private TextView txtChao;
    private String emailDangNhap = "";
    private String tenNguoiDung = "";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        layoutChuaDangNhap = findViewById(R.id.LayoutChuaDN);
        layoutDaDangNhap = findViewById(R.id.LayoutDaDN);
        btnDangNhap = findViewById(R.id.btnDN);
        btnDangKy = findViewById(R.id.btnDK);
        btnChoiGame = findViewById(R.id.btnChoi);
        btnDangXuat = findViewById(R.id.btnDX);
        txtChao = findViewById(R.id.txtChao);
        btnBangXepHang = findViewById(R.id.btnBangXepHang);

        btnChoiGame.setOnClickListener(v -> {
            Intent intent = new Intent(MainActivity.this, ChonManActivity.class);
            intent.putExtra("email", emailDangNhap);
            startActivity(intent);
        });

        btnBangXepHang.setOnClickListener(v -> {
            Intent intent = new Intent(MainActivity.this, BangXepHangActivity.class);
            intent.putExtra("email", emailDangNhap);
            startActivity(intent);
        });

        btnDangNhap.setOnClickListener(v -> {
            Intent intent = new Intent(MainActivity.this, DangNhapActivity.class);
            startActivity(intent);
        });

        btnDangKy.setOnClickListener(v -> {
            Intent intent = new Intent(MainActivity.this, DangKyActivity.class);
            startActivity(intent);
        });

        btnDangXuat.setOnClickListener(v -> {
            DBHelper dbHelper = new DBHelper(this);
            dbHelper.capNhatTrangThaiDangNhap(emailDangNhap, false);
            emailDangNhap = "";
            tenNguoiDung = "";
            Intent intent = new Intent(MainActivity.this, MainActivity.class);
            intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_NEW_TASK);
            startActivity(intent);
            finish();
        });
    }

    @Override
    protected void onResume() {
        super.onResume();
        DBHelper dbHelper = new DBHelper(this);
        emailDangNhap = dbHelper.layEmailDangNhap();
        if (emailDangNhap != null && !emailDangNhap.isEmpty()) {
            tenNguoiDung = dbHelper.layTenTheoEmail(emailDangNhap);
            layoutDaDangNhap.setVisibility(View.VISIBLE);
            layoutChuaDangNhap.setVisibility(View.GONE);
            txtChao.setText("Chào mừng trở lại, " + tenNguoiDung + "!");
        } else {
            layoutDaDangNhap.setVisibility(View.GONE);
            layoutChuaDangNhap.setVisibility(View.VISIBLE);
        }
    }
}
