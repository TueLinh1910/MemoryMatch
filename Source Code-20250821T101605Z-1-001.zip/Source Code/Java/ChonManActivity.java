package com.example.memorymatch;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;

public class ChonManActivity extends AppCompatActivity {
    private Button btnDe,btnThuong,btnKho,btnThoat;
    private String email = "";
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_chon_man);
        btnDe = findViewById(R.id.btnDe);
        btnThuong = findViewById(R.id.btnThuong);
        btnKho = findViewById(R.id.btnKho);
        btnThoat = findViewById(R.id.btnThoat);
        email = getIntent().getStringExtra("email");
        btnDe.setOnClickListener(v->{
            Intent intent = new Intent(ChonManActivity.this, GameActivity3x2.class);
            intent.putExtra("doKho", "de");
            intent.putExtra("email", email);
            startActivity(intent);
            finish();
        });
        btnThuong.setOnClickListener(v->{
            Intent intent = new Intent(ChonManActivity.this, GameActivity4x2.class);
            intent.putExtra("doKho", "thuong");
            intent.putExtra("email", email);
            startActivity(intent);
            finish();
        });
        btnKho.setOnClickListener(v->{
            Intent intent = new Intent(ChonManActivity.this, GameActivity4x4.class);
            intent.putExtra("doKho", "kho");
            intent.putExtra("email", email);
            startActivity(intent);
            finish();
        });
        btnThoat.setOnClickListener(v->{
            Intent intent = new Intent(ChonManActivity.this, MainActivity.class);
            intent.putExtra("email", email);
            startActivity(intent);
        });
    }
}