package com.example.memorymatch;

public class DiemSoGame {
    private String ten;
    private int diem,nuocDi;
    public DiemSoGame(String ten, int diem) {
        this.ten = ten;
        this.diem = diem;
        this.nuocDi = 0;
    }
    public DiemSoGame(String ten, int diem, int nuocDi) {
        this.ten = ten;
        this.diem = diem;
        this.nuocDi = nuocDi;
    }
    public String getTen() {
        return ten;
    }
    public int getDiem() {
        return diem;
    }
    public int getNuocDi() {
        return nuocDi;
    }
}
