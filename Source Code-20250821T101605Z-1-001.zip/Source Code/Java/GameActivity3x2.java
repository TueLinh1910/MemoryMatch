package com.example.memorymatch;

import android.content.Intent;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.GridLayout;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import java.util.ArrayList;
import java.util.Collections;

public class GameActivity3x2 extends AppCompatActivity {
    private GridLayout bangThe;
    private TextView tvDiem, tvThoiGian, tvKyLuc, tvNuocDi;
    private Button btnChoilai, btnThoat;
    private FrameLayout khungKetQua;
    private ArrayList<Integer> giaTriThe;
    private ArrayList<ImageButton> danhSachThe;
    private ImageButton the1, the2;
    private int chiSoThe1 = -1;
    private boolean dangXuLy = false;
    private int diem = 0, soCap = 0, nuocDi = 0;
    private final int TONG_THOI_GIAN = 120;
    private int thoiGianConLai = TONG_THOI_GIAN;
    private CountDownTimer dongHo;
    private DBHelper dbHelper;
    private int kyLuc;
    private String tenNguoiChoi;
    private String doKho = "de";
    private String email = "";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_game_3x2);
        khoiTaoView();
        batDauTroChoi();
        batDauDemThoiGian();
    }

    private void khoiTaoView() {
        bangThe = findViewById(R.id.bangThe);
        tvDiem = findViewById(R.id.tvDiem);
        tvNuocDi = findViewById(R.id.tvNuocDi);
        tvThoiGian = findViewById(R.id.tvThoiGian);
        tvKyLuc = findViewById(R.id.tvKyLuc);
        btnChoilai = findViewById(R.id.btnChoiLai);
        khungKetQua = findViewById(R.id.khungKetQua);
        btnThoat = findViewById(R.id.btnThoat);
        dbHelper = new DBHelper(this);
        email = getIntent().getStringExtra("email");
        doKho = getIntent().getStringExtra("doKho");
        tenNguoiChoi = dbHelper.layTenTheoEmail(email);
        kyLuc = dbHelper.layKyLuc(tenNguoiChoi, doKho);
        tvKyLuc.setText("Kỷ lục: " + kyLuc);
        btnChoilai.setOnClickListener(v -> {
            if (dongHo != null) dongHo.cancel();
            recreate();
        });
        btnThoat.setOnClickListener(v -> {
            Intent intent = new Intent(GameActivity3x2.this, ChonManActivity.class);
            intent.putExtra("email", email);
            intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_NEW_TASK);
            startActivity(intent);
            finish();
        });
    }

    private void batDauTroChoi() {
        danhSachThe = new ArrayList<>();
        giaTriThe = new ArrayList<>();
        for (int i = 0; i < 3; i++) {
            giaTriThe.add(i);
            giaTriThe.add(i);
        }
        Collections.shuffle(giaTriThe);
        bangThe.removeAllViews();
        bangThe.setColumnCount(2);
        int kichThuoc = (int) getResources().getDisplayMetrics().widthPixels / 3 - 30;
        for (int i = 0; i < 6; i++) {
            ImageButton the = new ImageButton(this);
            the.setImageResource(R.drawable.back_dark);
            the.setAdjustViewBounds(true);
            the.setBackground(null);
            GridLayout.LayoutParams params = new GridLayout.LayoutParams();
            params.width = kichThuoc;
            the.setLayoutParams(params);
            int chiSo = i;
            the.setOnClickListener(v -> xuLyChonThe(the, chiSo));
            bangThe.addView(the);
            danhSachThe.add(the);
        }
    }

    private void xuLyChonThe(ImageButton the, int chiSo) {
        if (dangXuLy || the == the1 || !the.isEnabled()) return;
        the.setImageResource(layAnhTuGiaTri(giaTriThe.get(chiSo)));
        nuocDi++;
        tvNuocDi.setText("Nước đi: " + nuocDi);
        if (the1 == null) {
            the1 = the;
            chiSoThe1 = chiSo;
        } else {
            the2 = the;
            dangXuLy = true;
            the.postDelayed(() -> kiemTraTrung(chiSo), 800);
        }
    }

    private void kiemTraTrung(int chiSo2) {
        if (giaTriThe.get(chiSoThe1).equals(giaTriThe.get(chiSo2))) {
            the1.setEnabled(false);
            the2.setEnabled(false);
            soCap++;
            diem += 10;
            tvDiem.setText("Điểm: " + diem);

            if (diem > kyLuc) {
                kyLuc = diem;
                tvKyLuc.setText("Kỷ lục: " + kyLuc);
                dbHelper.luuDiem(tenNguoiChoi, diem, nuocDi, doKho);
            }

            if (soCap == 3) {
                dongHo.cancel();
                diem += thoiGianConLai;
                tvDiem.setText("Điểm: " + diem);

                if (diem > kyLuc) {
                    kyLuc = diem;
                    tvKyLuc.setText("Kỷ lục: " + kyLuc);
                    dbHelper.luuDiem(tenNguoiChoi, diem, nuocDi, doKho);
                }
                hienKetQua(true);
            }
        } else {
            the1.setImageResource(R.drawable.back_dark);
            the2.setImageResource(R.drawable.back_dark);
        }
        the1 = null;
        the2 = null;
        dangXuLy = false;
    }

    private void batDauDemThoiGian() {
        dongHo = new CountDownTimer(TONG_THOI_GIAN * 1000L, 1000) {
            @Override
            public void onTick(long millisUntilFinished) {
                thoiGianConLai--;
                tvThoiGian.setText("Thời gian: " + thoiGianConLai + "s");
            }

            @Override
            public void onFinish() {
                tvThoiGian.setText("Thời gian: 0s");
                if (soCap < 3) {
                    hienKetQua(false);
                }
                voHieuHoaTatCaThe();
            }
        };
        dongHo.start();
    }

    private void voHieuHoaTatCaThe() {
        for (ImageButton the : danhSachThe) {
            the.setEnabled(false);
        }
    }

    private int layAnhTuGiaTri(int val) {
        switch (val) {
            case 0: return R.drawable.clubs_2;
            case 1: return R.drawable.clubs_3;
            case 2: return R.drawable.clubs_4;
            default: return R.drawable.back_dark;
        }
    }

    private void hienKetQua(boolean thang) {
        if (thang) {
            dbHelper.luuDiem(tenNguoiChoi, diem, nuocDi, doKho);
        }

        khungKetQua.setVisibility(View.VISIBLE);
        khungKetQua.removeAllViews();

        View popup = getLayoutInflater().inflate(R.layout.popup_result, null);
        FrameLayout.LayoutParams params = new FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.WRAP_CONTENT,
                FrameLayout.LayoutParams.WRAP_CONTENT
        );
        params.gravity = Gravity.CENTER;
        popup.setLayoutParams(params);

        TextView tieuDe = popup.findViewById(R.id.tvTieuDe);
        TextView diemSo = popup.findViewById(R.id.tvDiemSo);
        Button btnChoiLaiPopup = popup.findViewById(R.id.btnChoiLaiPopup);
        Button btnThoatPopup = popup.findViewById(R.id.btnThoatPopup);
        Button btnTiepTuc = popup.findViewById(R.id.btnTiepTucPopup);

        tieuDe.setText(thang ? "Vượt màn" : "Thất bại");
        diemSo.setText("Điểm của bạn: " + diem);

        if (thang) {
            btnTiepTuc.setVisibility(View.VISIBLE);
            btnThoatPopup.setVisibility(View.GONE);
        } else {
            btnTiepTuc.setVisibility(View.GONE);
            btnThoatPopup.setVisibility(View.VISIBLE);
        }

        btnChoiLaiPopup.setOnClickListener(v -> recreate());
        btnThoatPopup.setOnClickListener(v -> {
            Intent intent = new Intent(GameActivity3x2.this, ChonManActivity.class);
            intent.putExtra("email", email);
            intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_NEW_TASK);
            startActivity(intent);
            finish();
        });
        btnTiepTuc.setOnClickListener(v -> {
            Toast.makeText(this, "Tiếp tục chơi màn 4x2", Toast.LENGTH_SHORT).show();
            Intent intent = new Intent(GameActivity3x2.this, GameActivity4x2.class);
            intent.putExtra("doKho", "thuong");
            intent.putExtra("email", email);
            startActivity(intent);
            finish();
        });
        khungKetQua.addView(popup);
    }
}
