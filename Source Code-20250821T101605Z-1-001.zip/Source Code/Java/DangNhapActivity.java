package com.example.memorymatch;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class DangNhapActivity extends AppCompatActivity {

    private EditText edtEmail, edtMatKhau;
    private Button btnDangNhap, btnDangKy, btnBack;
    private DBHelper dbHelper;
    private boolean dangTai = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_dang_nhap);

        edtEmail = findViewById(R.id.edtEmail);
        edtMatKhau = findViewById(R.id.edtMatKhau);
        btnDangNhap = findViewById(R.id.btnDN);
        btnDangKy = findViewById(R.id.btnDK);
        btnBack = findViewById(R.id.btnBack);

        dbHelper = new DBHelper(this);

        btnDangNhap.setOnClickListener(v -> dangNhap());
        btnDangKy.setOnClickListener(v -> {
            Intent intent = new Intent(DangNhapActivity.this, DangKyActivity.class);
            startActivity(intent);
        });
        btnBack.setOnClickListener(v -> finish());
    }

    private void dangNhap() {
        String emailNhap = edtEmail.getText().toString().trim();
        String mkNhap = edtMatKhau.getText().toString().trim();
        if (emailNhap.isEmpty() || mkNhap.isEmpty()) {
            Toast.makeText(this, "Vui lòng nhập đầy đủ Email và Mật khẩu!", Toast.LENGTH_SHORT).show();
            return;
        }

        dangTai = true;
        btnDangNhap.setText("Đang đăng nhập...");

        edtEmail.postDelayed(() -> {
            dangTai = false;
            btnDangNhap.setText("Đăng Nhập");

            if (dbHelper.kiemTraDangNhap(emailNhap, mkNhap)) {
                dbHelper.capNhatTrangThaiDangNhap(emailNhap, true);
                Toast.makeText(this, "Đăng nhập thành công!", Toast.LENGTH_SHORT).show();
                Intent intent = new Intent(this, MainActivity.class);
                intent.putExtra("email", emailNhap);
                startActivity(intent);
                finish();
            } else {
                Toast.makeText(this, "Sai Email hoặc Mật khẩu!", Toast.LENGTH_SHORT).show();
            }
        }, 1500);
    }
}
