package com.example.memorymatch;

import android.content.Intent;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.GridLayout;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import java.util.ArrayList;
import java.util.Collections;

public class GameActivity4x2 extends AppCompatActivity {
    private GridLayout bangThe;
    private TextView tvDiem, tvThoiGian, tvKyLuc, tvNuocDi;
    private Button btnChoilai, btnThoat;
    private FrameLayout khungKetQua;
    private ArrayList<Integer> giaTriThe;
    private ArrayList<ImageButton> danhSachThe;
    private ImageButton the1, the2;
    private int chiSoThe1 = -1;
    private boolean dangXuLy = false;
    private int diem = 0, soCap = 0, nuocDi = 0;
    private final int TONG_THOI_GIAN = 120;
    private int thoiGianConLai = TONG_THOI_GIAN;
    private CountDownTimer dongHo;
    private DBHelper dbHelper;
    private int kyLuc;
    private String tenNguoiChoi;
    private String doKho = "thuong";
    private String email = "";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_game_4x2);
        khoiTaoView();
        batDauTroChoi();
        batDauDemThoiGian();
    }

    private void khoiTaoView() {
        bangThe = findViewById(R.id.bangThe);
        tvDiem = findViewById(R.id.tvDiem);
        tvNuocDi = findViewById(R.id.tvNuocDi);
        tvThoiGian = findViewById(R.id.tvThoiGian);
        tvKyLuc = findViewById(R.id.tvKyLuc);
        btnChoilai = findViewById(R.id.btnChoiLai);
        btnThoat = findViewById(R.id.btnThoat);
        khungKetQua = findViewById(R.id.khungKetQua);
        dbHelper = new DBHelper(this);
        email = getIntent().getStringExtra("email");
        doKho = getIntent().getStringExtra("doKho");
        tenNguoiChoi = dbHelper.layTenTheoEmail(email);
        kyLuc = dbHelper.layKyLuc(tenNguoiChoi, doKho);
        tvKyLuc.setText("Kỷ lục: " + kyLuc);
        btnChoilai.setOnClickListener(v -> {
            if (dongHo != null) dongHo.cancel();
            recreate();
        });
        btnThoat.setOnClickListener(v -> {
            Intent intent = new Intent(GameActivity4x2.this, ChonManActivity.class);
            intent.putExtra("email", email);
            intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_NEW_TASK);
            startActivity(intent);
            finish();
        });
    }

    private void batDauTroChoi() {
        danhSachThe = new ArrayList<>();
        giaTriThe = new ArrayList<>();
        for (int i = 0; i < 4; i++) {
            giaTriThe.add(i);
            giaTriThe.add(i);
        }
        Collections.shuffle(giaTriThe);
        bangThe.removeAllViews();
        bangThe.setColumnCount(2);
        int kichThuoc = (int) getResources().getDisplayMetrics().widthPixels / 3 - 32;
        for (int i = 0; i < 8; i++) {
            ImageButton the = new ImageButton(this);
            the.setImageResource(R.drawable.back_dark);
            the.setAdjustViewBounds(true);
            the.setBackground(null);
            GridLayout.LayoutParams params = new GridLayout.LayoutParams();
            params.width = kichThuoc;
            the.setLayoutParams(params);
            int chiSo = i;
            the.setOnClickListener(v -> xuLyChonThe(the, chiSo));
            bangThe.addView(the);
            danhSachThe.add(the);
        }
    }

    private void xuLyChonThe(ImageButton the, int chiSo) {
        if (dangXuLy || the == the1 || !the.isEnabled()) return;

        the.setImageResource(layAnhTuGiaTri(giaTriThe.get(chiSo)));
        nuocDi++;
        tvNuocDi.setText("Nước đi: " + nuocDi);
        if (the1 == null) {
            the1 = the;
            chiSoThe1 = chiSo;
        } else {
            the2 = the;
            dangXuLy = true;
            the.postDelayed(() -> kiemTraTrung(chiSo), 800);
        }
    }

    private void kiemTraTrung(int chiSo2) {
        if (giaTriThe.get(chiSoThe1).equals(giaTriThe.get(chiSo2))) {
            the1.setEnabled(false);
            the2.setEnabled(false);
            soCap++;
            diem += 10;
            tvDiem.setText("Điểm: " + diem);
            if (diem > kyLuc) {
                kyLuc = diem;
                tvKyLuc.setText("Kỷ lục: " + kyLuc);
                dbHelper.luuDiem(tenNguoiChoi, diem, nuocDi, doKho);
            }
            if (soCap == 4) {
                dongHo.cancel();
                diem += thoiGianConLai;
                tvDiem.setText("Điểm: " + diem);
                if (diem > kyLuc) {
                    kyLuc = diem;
                    tvKyLuc.setText("Kỷ lục: " + kyLuc);
                    dbHelper.luuDiem(tenNguoiChoi, diem, nuocDi, doKho);
                }
                hienKetQua(true);
            }
        } else {
            the1.setImageResource(R.drawable.back_dark);
            the2.setImageResource(R.drawable.back_dark);
        }
        the1 = null;
        the2 = null;
        dangXuLy = false;
    }

    private void batDauDemThoiGian() {
        dongHo = new CountDownTimer(TONG_THOI_GIAN * 1000L, 1000) {
            @Override
            public void onTick(long millisUntilFinished) {
                thoiGianConLai--;
                tvThoiGian.setText("Thời gian: " + thoiGianConLai + "s");
            }
            @Override
            public void onFinish() {
                tvThoiGian.setText("Thời gian: 0s");
                if (soCap < 4) {
                    hienKetQua(false);
                }
                voHieuHoaTatCaThe();
            }
        };
        dongHo.start();
    }

    private void voHieuHoaTatCaThe() {
        for (ImageButton the : danhSachThe) {
            the.setEnabled(false);
        }
    }

    private int layAnhTuGiaTri(int val) {
        switch (val) {
            case 0: return R.drawable.clubs_2;
            case 1: return R.drawable.clubs_3;
            case 2: return R.drawable.clubs_4;
            case 3: return R.drawable.clubs_5;
            default: return R.drawable.back_dark;
        }
    }

    private void hienKetQua(boolean thang) {
        if (thang) {
            dbHelper.luuDiem(tenNguoiChoi, diem, nuocDi, doKho);
        }

        khungKetQua.setVisibility(View.VISIBLE);
        khungKetQua.removeAllViews();

        View popup = getLayoutInflater().inflate(R.layout.popup_result, null);
        FrameLayout.LayoutParams params = new FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.WRAP_CONTENT,
                FrameLayout.LayoutParams.WRAP_CONTENT
        );
        params.gravity = Gravity.CENTER;
        popup.setLayoutParams(params);

        TextView tieuDe = popup.findViewById(R.id.tvTieuDe);
        TextView diemSo = popup.findViewById(R.id.tvDiemSo);
        Button btnChoilai = popup.findViewById(R.id.btnChoiLaiPopup);
        Button btnThoat = popup.findViewById(R.id.btnThoatPopup);
        Button btnTiepTuc = popup.findViewById(R.id.btnTiepTucPopup);

        tieuDe.setText(thang ? "Vượt màn" : "Thất bại");
        diemSo.setText("Điểm của bạn: " + diem);

        if (thang) {
            btnTiepTuc.setVisibility(View.VISIBLE);
            btnThoat.setVisibility(View.GONE);
        } else {
            btnTiepTuc.setVisibility(View.GONE);
            btnThoat.setVisibility(View.VISIBLE);
        }

        btnChoilai.setOnClickListener(v -> recreate());
        btnThoat.setOnClickListener(v -> {
            Intent intent = new Intent(GameActivity4x2.this, ChonManActivity.class);
            intent.putExtra("email", email);
            startActivity(intent);
        });
        btnTiepTuc.setOnClickListener(v -> {
            Toast.makeText(this, "Tiếp tục chơi màn 4x4", Toast.LENGTH_SHORT).show();
            Intent intent = new Intent(GameActivity4x2.this, GameActivity4x4.class);
            intent.putExtra("doKho", "kho");
            intent.putExtra("email", email);
            startActivity(intent);
        });
        khungKetQua.addView(popup);
    }
}
