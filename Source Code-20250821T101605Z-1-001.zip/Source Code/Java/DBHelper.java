package com.example.memorymatch;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.content.ContentValues;
import android.database.Cursor;
import android.util.Log;

import java.util.ArrayList;
import java.util.List;

public class DBHelper extends SQLiteOpenHelper {
    private static final String DB_NAME = "BXH.db";
    private static final int DB_VERSION = 2;

    // Bảng BXH
    private static final String TABLE_BXH = "bxh";
    private static final String COL_ID = "id";
    private static final String COL_DIEM = "diem";
    private static final String COL_NUOC_DI = "nuocdi";
    private static final String COL_DO_KHO = "dokho";

    // Bảng người dùng
    private static final String TABLE_USERS = "users";
    private static final String COL_TEN = "ten";
    private static final String COL_EMAIL = "email";
    private static final String COL_MATKHAU = "matkhau";

    public DBHelper(Context context) {
        super(context, DB_NAME, null, DB_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        String queryBXH = "CREATE TABLE " + TABLE_BXH + "(" +
                COL_ID + " INTEGER PRIMARY KEY AUTOINCREMENT," +
                COL_TEN + " TEXT," +
                COL_DIEM + " INTEGER," +
                COL_NUOC_DI + " INTEGER," +
                COL_DO_KHO + " TEXT)";
        db.execSQL(queryBXH);

        String queryUser = "CREATE TABLE " + TABLE_USERS + " (" +
                "id INTEGER PRIMARY KEY AUTOINCREMENT," +
                COL_TEN + " TEXT," +
                COL_EMAIL + " TEXT UNIQUE," +
                COL_MATKHAU + " TEXT," +
                "trangthai INTEGER DEFAULT 0)";
        db.execSQL(queryUser);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldV, int newV) {
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_BXH);
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_USERS);
        onCreate(db);
    }
    public void capNhatTrangThaiDangNhap(String email, boolean dangNhap) {
        SQLiteDatabase db = getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put("trangthai", dangNhap ? 1 : 0);
        db.update(TABLE_USERS, values, "email = ?", new String[]{email});
    }
    public String layEmailDangNhap() {
        SQLiteDatabase db = getReadableDatabase();
        Cursor cursor = db.rawQuery("SELECT email FROM users WHERE trangthai = 1 LIMIT 1", null);
        String email = "";
        if (cursor.moveToFirst()) {
            email = cursor.getString(0);
        }
        cursor.close();
        return email;
    }
    public String layTenTheoEmail(String email) {
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery("SELECT ten FROM users WHERE email = ?", new String[]{email});
        String ten = "";
        if (cursor.moveToFirst()) {
            ten = cursor.getString(0);
        }
        cursor.close();
        return ten;
    }
    public boolean themNguoiDung(String ten, String email, String matkhau) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COL_TEN, ten);
        values.put(COL_EMAIL, email);
        values.put(COL_MATKHAU, matkhau);
        long ketQua = db.insert(TABLE_USERS, null, values);
        return ketQua != -1;
    }
    public boolean kiemTraEmailTonTai(String email) {
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery("SELECT * FROM " + TABLE_USERS + " WHERE " + COL_EMAIL + " = ?", new String[]{email});
        boolean tonTai = cursor.getCount() > 0;
        cursor.close();
        return tonTai;
    }
    public boolean kiemTraDangNhap(String email, String matkhau) {
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery(
                "SELECT * FROM " + TABLE_USERS + " WHERE " + COL_EMAIL + " = ? AND " + COL_MATKHAU + " = ?",
                new String[]{email, matkhau}
        );
        boolean hopLe = cursor.getCount() > 0;
        cursor.close();
        return hopLe;
    }
    public int layKyLuc(String ten, String doKho) {
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery("SELECT diem FROM bxh WHERE ten = ? AND dokho = ?", new String[]{ten, doKho});
        int kyLuc = 0;
        if (cursor.moveToFirst()) {
            kyLuc = cursor.getInt(0);
        }
        cursor.close();
        return kyLuc;
    }
    // ====================== BẢNG XẾP HẠNG =========================
    public void luuDiem(String ten, int diem, int nuocDi, String doKho) {
        SQLiteDatabase db = getWritableDatabase();
        Cursor c = db.query(TABLE_BXH, null, COL_TEN + "=? AND " + COL_DO_KHO + "=?",
                new String[]{ten, doKho}, null, null, null);

        if (c.moveToFirst()) {
            int diemCu = c.getInt(c.getColumnIndexOrThrow(COL_DIEM));
            int nuocDiCu = c.getInt(c.getColumnIndexOrThrow(COL_NUOC_DI));
            if (diem > diemCu || (diem == diemCu && nuocDi < nuocDiCu)) {
                ContentValues values = new ContentValues();
                values.put(COL_DIEM, diem);
                values.put(COL_NUOC_DI, nuocDi);
                db.update(TABLE_BXH, values, COL_TEN + "=? AND " + COL_DO_KHO + "=?", new String[]{ten, doKho});
            }
        } else {
            ContentValues values = new ContentValues();
            values.put(COL_TEN, ten);
            values.put(COL_DIEM, diem);
            values.put(COL_NUOC_DI, nuocDi);
            values.put(COL_DO_KHO, doKho);
            db.insert(TABLE_BXH, null, values);
        }
        Log.d("DBHelper", "Đã lưu điểm vào SQLite");
        c.close();
        db.close();
    }

    public List<DiemSoGame> layBXH(String doKho) {
        List<DiemSoGame> danhSach = new ArrayList<>();
        SQLiteDatabase db = getReadableDatabase();
        Cursor cursor = db.query(TABLE_BXH, null,
                COL_DO_KHO + "=?", new String[]{doKho},
                null, null, COL_DIEM + " DESC, " + COL_NUOC_DI + " ASC");

        if (cursor.moveToFirst()) {
            do {
                String ten = cursor.getString(cursor.getColumnIndexOrThrow(COL_TEN));
                int diem = cursor.getInt(cursor.getColumnIndexOrThrow(COL_DIEM));
                int nuocDi = cursor.getInt(cursor.getColumnIndexOrThrow(COL_NUOC_DI));
                danhSach.add(new DiemSoGame(ten, diem, nuocDi));
            } while (cursor.moveToNext());
        }

        cursor.close();
        db.close();
        return danhSach;
    }
}


