package com.example.memorymatch;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

public class BXHAdapter extends RecyclerView.Adapter<BXHAdapter.ScoreViewHolder> {
    private List<DiemSoGame> DsDiem;
    public BXHAdapter(List<DiemSoGame> scoreList) {
        this.DsDiem = scoreList;
    }
    @NonNull
    @Override
    public ScoreViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.item_bxh, parent, false);
        return new ScoreViewHolder(view);
    }
    @Override
    public void onBindViewHolder(@NonNull ScoreViewHolder holder, int position) {
        DiemSoGame score = DsDiem.get(position);
        holder.tvHang.setText(String.valueOf(position + 1));
        holder.tvTen.setText(score.getTen());
        holder.tvDiem.setText(String.valueOf(score.getDiem()));
        holder.tvNuocDi.setText("Nước đi: " + score.getNuocDi());
    }
    @Override
    public int getItemCount() {
        return DsDiem.size();
    }
    static class ScoreViewHolder extends RecyclerView.ViewHolder {
        TextView tvHang, tvTen, tvDiem, tvNuocDi;
        public ScoreViewHolder(@NonNull View itemView) {
            super(itemView);
            tvHang = itemView.findViewById(R.id.tvHang);
            tvTen = itemView.findViewById(R.id.tvTen);
            tvDiem = itemView.findViewById(R.id.tvDiem);
            tvNuocDi = itemView.findViewById(R.id.tvNuocDi);
        }
    }
}
