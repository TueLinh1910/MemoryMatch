package com.example.memorymatch;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class DangKyActivity extends AppCompatActivity {

    private EditText edtTen, edtEmail, edtMatKhau, edtXNMatKhau;
    private Button btnDangKy, btnDangNhap, btnBack;

    private DBHelper dbHelper;
    private boolean dangTai = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_dang_ky);

        edtTen = findViewById(R.id.edtTen);
        edtEmail = findViewById(R.id.edtEmail);
        edtMatKhau = findViewById(R.id.edtMatKhau);
        edtXNMatKhau = findViewById(R.id.edtXNMatKhau);
        btnDangKy = findViewById(R.id.btnDK);
        btnDangNhap = findViewById(R.id.btnDN);
        btnBack = findViewById(R.id.btnBack);

        dbHelper = new DBHelper(this);

        btnDangKy.setOnClickListener(v -> xuLyDangKy());

        btnDangNhap.setOnClickListener(v -> {
            Intent intent = new Intent(DangKyActivity.this, DangNhapActivity.class);
            startActivity(intent);
        });
        btnBack.setOnClickListener(v -> finish());
    }

    private void xuLyDangKy() {
        String ten = edtTen.getText().toString().trim();
        String email = edtEmail.getText().toString().trim();
        String matKhau = edtMatKhau.getText().toString().trim();
        String xacNhanMatKhau = edtXNMatKhau.getText().toString().trim();

        if (ten.isEmpty() || email.isEmpty() || matKhau.isEmpty() || xacNhanMatKhau.isEmpty()) {
            Toast.makeText(this, "Vui lòng nhập đầy đủ thông tin", Toast.LENGTH_SHORT).show();
            return;
        }

        if (matKhau.length() < 6) {
            Toast.makeText(this, "Mật khẩu phải có ít nhất 6 ký tự", Toast.LENGTH_SHORT).show();
            return;
        }

        if (!matKhau.equals(xacNhanMatKhau)) {
            Toast.makeText(this, "Xác nhận mật khẩu không khớp", Toast.LENGTH_SHORT).show();
            return;
        }

        if (dbHelper.kiemTraEmailTonTai(email)) {
            Toast.makeText(this, "Email đã tồn tại, vui lòng chọn email khác.", Toast.LENGTH_SHORT).show();
            return;
        }

        dangTai = true;
        btnDangKy.setText("Đang đăng ký...");
        edtEmail.postDelayed(() -> {
            dangTai = false;
            btnDangKy.setText("Đăng Ký");

            boolean ketQua = dbHelper.themNguoiDung(ten, email, matKhau);
            if (ketQua) {
                Toast.makeText(this, "Đăng ký thành công! Vui lòng đăng nhập.", Toast.LENGTH_SHORT).show();
                startActivity(new Intent(DangKyActivity.this, DangNhapActivity.class));
                finish();
            } else {
                Toast.makeText(this, "Đăng ký thất bại!", Toast.LENGTH_SHORT).show();
            }
        }, 1500);
    }
}
